<?php

if (isset($_POST["register"]))
	 {
		   $password=$_POST["password"];
		   if(checkPassword($password))
		   		{
					   $email=$_POST["email"];
					   $gender=$_POST["gender"];
		               echo "your Email is : ".$email."<br>";
                       echo "your gender is : ".$gender."<br>";
                       if(isset($_POST["colors"]))
                			 {
					             $colors=$_POST["colors"];
					             echo " Colors : ";
					             foreach($colors as $color)
					             	{
					                	echo $color."  ";
                             		}
        
       						 }

				        else
				        	{
					            $colors=" Color : No favorite color! <br>";
					            echo $colors;
				       	    }


        echo"<br>Registered successfully!";

              }
              else
              	{
       				  echo "enter your password bettwen 8 character to 16 character ";
    		    }
               }
    else
    	{
			header("location:form.html");
    }
function checkPassword($pass){
 return strlen($pass)>8 && strlen($pass)<16;
    }



?>